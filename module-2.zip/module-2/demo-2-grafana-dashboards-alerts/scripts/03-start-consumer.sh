#!/usr/bin/env bash
set -euo pipefail

TOPIC="${TOPIC:-ops-demo-observability}"
GROUP="${GROUP:-ops-demo-cg}"

echo "Starting consumer inside broker1 (topic=$TOPIC, group=$GROUP)..."

# Kill any prior consumer for same topic/group and reset log
docker exec broker1 bash -lc "
  pkill -f \"kafka-console-consumer.*--topic ${TOPIC}.*--group ${GROUP}\" >/dev/null 2>&1 || true
  rm -f /tmp/ops-demo-consumer.log
" >/dev/null

# IMPORTANT: CLI tools are Java processes too; broker sets JMX_PORT=9999 which will
# crash CLI with 'address already in use'. Strip JMX env for the CLI process.
docker exec -d broker1 bash -lc "
  env -u JMX_PORT -u KAFKA_JMX_PORT -u KAFKA_JMX_OPTS -u KAFKA_OPTS -u JAVA_TOOL_OPTIONS \
    kafka-console-consumer \
      --bootstrap-server broker1:9092 \
      --topic \"${TOPIC}\" \
      --group \"${GROUP}\" \
      --from-beginning \
      --consumer-property enable.auto.commit=true \
      --consumer-property auto.commit.interval.ms=1000 \
      --consumer-property auto.offset.reset=earliest \
      >> /tmp/ops-demo-consumer.log 2>&1
"

# Quick health check
sleep 1
echo "Consumer process (inside broker1):"
docker exec broker1 bash -lc "pgrep -af kafka-console-consumer || true"

echo "Consumer log (last 30 lines):"
docker exec broker1 bash -lc "tail -n 30 /tmp/ops-demo-consumer.log || true"

echo "Done. To follow logs: docker exec broker1 tail -f /tmp/ops-demo-consumer.log"
