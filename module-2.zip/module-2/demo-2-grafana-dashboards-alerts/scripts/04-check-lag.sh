#!/usr/bin/env bash
set -euo pipefail

TOPIC="${TOPIC:-ops-demo-observability}"
GROUP="${GROUP:-ops-demo-cg}"

echo
echo "Lag Snapshot (group=$GROUP, topic=$TOPIC)"
echo "--------------------------------------------------------------------------"

out="$(docker exec broker1 bash -lc "
  env -u JMX_PORT -u KAFKA_JMX_PORT -u KAFKA_JMX_OPTS -u KAFKA_OPTS -u JAVA_TOOL_OPTIONS \
    kafka-consumer-groups --bootstrap-server broker1:9092 --describe --group '$GROUP' 2>&1 || true
")"

if echo "$out" | grep -qi "does not exist"; then
  echo "Consumer group not found yet."
  echo "If the producer is running, the consumer likely failed to start."
  echo "Check: docker exec broker1 tail -n 80 /tmp/ops-demo-consumer.log"
  exit 0
fi

if [[ -z "${out// }" ]]; then
  echo "No output yet. Either the group doesn't exist, or offsets haven't been committed."
  echo "Tip: run ./scripts/03-start-consumer.sh, wait ~2–5s, then retry."
  exit 0
fi

# Print header + rows for our topic.
echo "$out" | awk -v t="$TOPIC" '
NR==1 {print; next}
$2==t {print}
'

echo "--------------------------------------------------------------------------"
