#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$DIR/00-env.sh" 2>/dev/null || true

# Hard defaults so you can run: ./scripts/02-start-load.sh
DURATION_SEC="${DURATION_SEC:-180}"     # 3 minutes
TARGET_RPS="${TARGET_RPS:-20000}"       # stable pressure, usually safe on laptop docker
RECORD_SIZE="${RECORD_SIZE:-512}"
ACKS="${ACKS:-1}"

TOPIC="${TOPIC:-m3-correlation-topic}"
BOOTSTRAP="${BOOTSTRAP:-broker1:9092}"

# Run inside a broker container so Kafka CLI is guaranteed available
RUN_IN_CONTAINER="${RUN_IN_CONTAINER:-broker3}"

CHUNK_SEC="${CHUNK_SEC:-10}"
TOTAL_CHUNKS=$(( (DURATION_SEC + CHUNK_SEC - 1) / CHUNK_SEC ))
CHUNK_RECORDS=$(( TARGET_RPS * CHUNK_SEC ))

echo "Producer load starting"
echo "  topic=$TOPIC bootstrap=$BOOTSTRAP"
echo "  duration=${DURATION_SEC}s target_rps=$TARGET_RPS record_size=$RECORD_SIZE acks=$ACKS"
echo

for i in $(seq 1 "$TOTAL_CHUNKS"); do
  echo "---- load chunk $i/$TOTAL_CHUNKS ($(date +%H:%M:%S)) ----"

  # If broker2 restarts you may see metadata warnings. That is expected and teachable.
  docker exec "$RUN_IN_CONTAINER" bash -lc "
    kafka-producer-perf-test \
      --topic '$TOPIC' \
      --num-records '$CHUNK_RECORDS' \
      --record-size '$RECORD_SIZE' \
      --throughput '$TARGET_RPS' \
      --producer-props bootstrap.servers='$BOOTSTRAP' acks='$ACKS' client.id='perf-producer-m3'
  " || true
done

echo
echo "Producer load finished ($(date +%H:%M:%S))."
