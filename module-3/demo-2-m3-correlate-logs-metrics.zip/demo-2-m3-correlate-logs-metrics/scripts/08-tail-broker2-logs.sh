#!/usr/bin/env bash
set -euo pipefail

# Show only the log lines that actually help you correlate with Grafana.
# Keep it readable: no offsets truncation spam, no long stacks.

SINCE_SEC="${SINCE_SEC:-120}"   # last 2 minutes

PATTERN='ERROR|WARN|Resigned|Starting|Shutdown|Controller|Leader|ISR|UnderReplicated|NotLeaderOrFollower|NETWORK_EXCEPTION|Request timed out|kafka.controller|kafka.server.ReplicaManager|kafka.server.KafkaServer'

echo "Broker2 high-signal logs (since last ${SINCE_SEC}s)"
echo "Tip: when Grafana latency spikes, read 1–2 lines with that timestamp"
echo

# --since works with docker logs
docker logs -f --since "${SINCE_SEC}s" broker2 2>&1 \
  | stdbuf -oL egrep -i "$PATTERN" \
  | stdbuf -oL sed -E 's/([[:space:]]{2,})/ /g'
