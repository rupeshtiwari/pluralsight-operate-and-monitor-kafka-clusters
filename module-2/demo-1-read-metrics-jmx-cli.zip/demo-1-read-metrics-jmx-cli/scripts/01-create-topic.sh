#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$DIR/_kafka.sh"

TOPIC="${TOPIC:-ops-demo-observability}"
BROKER="${BROKER:-broker1}"

kafka_exec "$BROKER" "kafka-topics --bootstrap-server $BROKER:9092 --create --if-not-exists --topic $TOPIC --partitions 3 --replication-factor 3" >/dev/null

echo "Created topic $TOPIC."
