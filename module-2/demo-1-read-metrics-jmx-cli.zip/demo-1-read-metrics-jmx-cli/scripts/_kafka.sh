#!/usr/bin/env bash
set -euo pipefail

# Always run Kafka CLI inside a broker container WITHOUT inheriting broker JMX env vars.
# This prevents: "Port already in use: 9999" when running kafka-consumer-groups, kafka-topics, etc.
kafka_exec() {
  local broker="${1:-broker1}"; shift
  docker exec "$broker" bash -lc \
    'env -u JMX_PORT -u KAFKA_JMX_PORT -u KAFKA_JMX_OPTS -u JAVA_TOOL_OPTIONS '"$*" 
}
