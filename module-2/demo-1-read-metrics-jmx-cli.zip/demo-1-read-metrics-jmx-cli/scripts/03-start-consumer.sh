#!/usr/bin/env bash
set -euo pipefail

TOPIC="${TOPIC:-ops-demo-observability}"
GROUP="${GROUP:-ops-demo-cg}"
BROKER="${BROKER:-broker1}"

log="/tmp/ops-demo-consumer.log"

# Kill any previous consumer we started
pkill -f "ops-demo-consumer" >/dev/null 2>&1 || true

# Start a real consumer group member (so offsets exist and lag is measurable)
nohup bash -lc "
  exec -a ops-demo-consumer \
  docker exec $BROKER bash -lc '
    env -u JMX_PORT -u KAFKA_JMX_PORT -u KAFKA_JMX_OPTS -u JAVA_TOOL_OPTIONS \
    kafka-console-consumer \
      --bootstrap-server $BROKER:9092 \
      --topic $TOPIC \
      --group $GROUP \
      --property print.timestamp=true \
      --property print.key=true \
      --property print.value=false
  '
" >\"$log\" 2>&1 &

echo "Consumer started for group=$GROUP topic=$TOPIC. PID=$!"
echo "Log: $log"
