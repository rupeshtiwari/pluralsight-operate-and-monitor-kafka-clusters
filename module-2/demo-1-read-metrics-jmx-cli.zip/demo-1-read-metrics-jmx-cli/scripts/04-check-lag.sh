#!/usr/bin/env bash
set -euo pipefail

GROUP="${GROUP:-ops-demo-cg}"
TOPIC="${TOPIC:-ops-demo-observability}"
BROKER="${BROKER:-broker1}"

echo ""
echo "Lag Snapshot (group=$GROUP, topic=$TOPIC)"
echo "------------------------------------------------------------"

# List groups (proves group exists)
groups=$(
  docker exec "$BROKER" bash -lc \
  "env -u JMX_PORT -u KAFKA_JMX_PORT -u KAFKA_JMX_OPTS -u JAVA_TOOL_OPTIONS \
   kafka-consumer-groups --bootstrap-server $BROKER:9092 --list 2>/dev/null" || true
)

if ! echo "$groups" | grep -qx "$GROUP"; then
  echo "Consumer group not found yet."
  echo "Fix: run ./scripts/03-start-consumer.sh & then re-run this."
  exit 0
fi

# Show describe output (and filter topic safely)
out=$(
  docker exec "$BROKER" bash -lc \
  "env -u JMX_PORT -u KAFKA_JMX_PORT -u KAFKA_JMX_OPTS -u JAVA_TOOL_OPTIONS \
   kafka-consumer-groups --bootstrap-server $BROKER:9092 --describe --group $GROUP 2>/dev/null" || true
)

# Always show header
echo "$out" | head -n 1

# Show topic rows if present
rows=$(echo "$out" | awk -v t="$TOPIC" 'NR>1 && $1==t {print}')
if [[ -n "${rows:-}" ]]; then
  echo "$rows"
else
  echo "(No rows for topic '$TOPIC' yet)"
  echo "Quick proof (full group describe):"
  echo "$out" | sed -n '1,12p'
fi
